#!/usr/bin/env python3
import argparse
import base64
import json
import mimetypes
import os
from pathlib import Path
import sys
import urllib.error
import urllib.request


def load_codex_auth_key():
    auth_path = Path.home() / ".codex" / "auth.json"
    if not auth_path.exists():
        return None
    try:
        data = json.loads(auth_path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return data.get("NAN_API_KEY") or data.get("OPENAI_API_KEY")


def get_prompt(args):
    if args.prompt and args.prompt_file:
        raise SystemExit("Use --prompt or --prompt-file, not both.")
    if args.prompt_file:
        return Path(args.prompt_file).read_text(encoding="utf-8").strip()
    if args.prompt:
        return args.prompt.strip()
    raise SystemExit("Missing prompt. Use --prompt or --prompt-file.")


def normalize_base_url(base_url):
    base_url = (base_url or "https://cn.meta-api.vip").strip().rstrip("/")
    if base_url.endswith("/v1"):
        base_url = base_url[:-3].rstrip("/")
    return base_url


def find_image_base64(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"result", "b64_json", "partial_image_b64"} and isinstance(item, str):
                if len(item) > 1000 and all(ch.isalnum() or ch in "+/=" for ch in item[:200]):
                    return item, key
        for item in value.values():
            found = find_image_base64(item)
            if found:
                return found
    if isinstance(value, list):
        for item in value:
            found = find_image_base64(item)
            if found:
                return found
    return None


def image_path_to_data_url(image_path):
    path = Path(image_path)
    if not path.exists():
        raise SystemExit(f"Image not found: {path}")
    mime = mimetypes.guess_type(path.name)[0] or "image/png"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def redact_payload_for_log(value):
    if isinstance(value, dict):
        redacted = {}
        for key, item in value.items():
            if key == "image_url" and isinstance(item, str) and item.startswith("data:"):
                prefix = item.split(",", 1)[0]
                redacted[key] = f"{prefix},<base64:{len(item)} chars>"
            else:
                redacted[key] = redact_payload_for_log(item)
        return redacted
    if isinstance(value, list):
        return [redact_payload_for_log(item) for item in value]
    return value


def save_base64_image(image_base64, output_path, force=False):
    out = Path(output_path)
    if out.exists() and not force:
        raise SystemExit(f"Output already exists: {out} (use --force to overwrite)")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(base64.b64decode(image_base64))
    return out


def request_json(url, api_key, payload, timeout):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8", "replace"))


def request_multipart_json(url, api_key, fields, files, timeout):
    boundary = "----meta-api-imagegen-boundary"
    chunks = []
    for name, value in fields.items():
        chunks.append(f"--{boundary}\r\n".encode("utf-8"))
        chunks.append(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode("utf-8"))
        chunks.append(str(value).encode("utf-8"))
        chunks.append(b"\r\n")
    for name, path in files:
        file_path = Path(path)
        if not file_path.exists():
            raise SystemExit(f"Image not found: {file_path}")
        mime = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        chunks.append(f"--{boundary}\r\n".encode("utf-8"))
        chunks.append(
            f'Content-Disposition: form-data; name="{name}"; filename="{file_path.name}"\r\n'.encode("utf-8")
        )
        chunks.append(f"Content-Type: {mime}\r\n\r\n".encode("utf-8"))
        chunks.append(file_path.read_bytes())
        chunks.append(b"\r\n")
    chunks.append(f"--{boundary}--\r\n".encode("utf-8"))
    body = b"".join(chunks)
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8", "replace"))


def try_direct_image_api(args, api_key, base_url, prompt):
    if args.images:
        url = f"{base_url}/v1/images/edits"
        print(f"TRY_DIRECT_EDIT={url} MODEL={args.image_model}")
        if args.dry_run:
            print(
                json.dumps(
                    {
                        "model": args.image_model,
                        "prompt": prompt,
                        "size": args.size,
                        "quality": args.quality,
                        "n": 1,
                        "output_format": args.output_format,
                        "image": args.images[0],
                        "mask": args.mask,
                    },
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
            )
            return False
        fields = {
            "model": args.image_model,
            "prompt": prompt,
            "size": args.size,
            "quality": args.quality,
            "n": 1,
            "output_format": args.output_format,
        }
        files = [("image", args.images[0])]
        if args.mask:
            files.append(("mask", args.mask))
        status, data = request_multipart_json(url, api_key, fields, files, timeout=420)
    else:
        url = f"{base_url}/v1/images/generations"
        payload = {
            "model": args.image_model,
            "prompt": prompt,
            "size": args.size,
            "quality": args.quality,
            "n": 1,
            "output_format": args.output_format,
        }
        print(f"TRY_DIRECT={url} MODEL={args.image_model}")
        if args.dry_run:
            print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
            return False
        status, data = request_json(url, api_key, payload, timeout=420)
    items = data.get("data") or []
    if items:
        item = items[0]
        if item.get("b64_json"):
            save_base64_image(item["b64_json"], args.out, args.force)
            print(f"HTTP_STATUS={status}")
            print(f"WROTE_IMAGE={args.out}")
            print(f"MODEL={args.image_model}")
            return True
    raise RuntimeError("Direct Image API response had no data[0].b64_json.")


def try_responses_image_tool(args, api_key, base_url, prompt):
    url = f"{base_url}/v1/responses"
    content = [{"type": "input_text", "text": prompt}]
    for image_path in args.images or []:
        content.append({"type": "input_image", "image_url": image_path_to_data_url(image_path)})
    payload = {
        "model": args.responses_model,
        "input": [
            {
                "role": "user",
                "content": content,
            }
        ],
        "tools": [
            {
                "type": "image_generation",
                "size": args.size,
                "quality": args.quality,
                "output_format": args.output_format,
            }
        ],
        "tool_choice": {"type": "image_generation"},
        "stream": True,
    }
    mode = "edit" if args.images else "generate"
    print(f"TRY_RESPONSES={url} MODEL={args.responses_model} MODE={mode}")
    if args.dry_run:
        print(json.dumps(redact_payload_for_log(payload), ensure_ascii=False, separators=(",", ":")))
        return

    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        },
        method="POST",
    )
    events = 0
    event_types = []
    latest_image_base64 = None
    latest_image_key = None
    with urllib.request.urlopen(req, timeout=600) as resp:
        status = resp.status
        for raw in resp:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data: "):
                continue
            data = line[6:].strip()
            if not data or data == "[DONE]":
                continue
            events += 1
            try:
                obj = json.loads(data)
            except json.JSONDecodeError:
                continue
            if obj.get("type"):
                event_types.append(obj["type"])
                event_types = event_types[-8:]
            found = find_image_base64(obj)
            if found:
                latest_image_base64, latest_image_key = found
                if latest_image_key in {"result", "b64_json"}:
                    break
    if latest_image_base64:
        save_base64_image(latest_image_base64, args.out, args.force)
        print(f"HTTP_STATUS={status}")
        print(f"SSE_EVENTS_READ={events}")
        print(f"LAST_EVENT_TYPES={','.join(event_types)}")
        print(f"IMAGE_SOURCE_FIELD={latest_image_key}")
        print(f"WROTE_IMAGE={args.out}")
        print(f"MODEL={args.responses_model} + image_generation tool")
        print("NOTE=This is not a direct gpt-image-2 Image API call; the provider may map the image_generation tool internally.")
        return
    raise RuntimeError("Responses stream completed but no image base64 was found.")


def build_parser():
    parser = argparse.ArgumentParser(description="Generate or edit images through cn.meta-api.vip Responses image_generation.")
    parser.add_argument("--api-key")
    parser.add_argument("--base-url", default="https://cn.meta-api.vip")
    parser.add_argument("--prompt")
    parser.add_argument("--prompt-file")
    parser.add_argument("--image", dest="images", action="append", help="Input image path for edit/reference mode. Repeat for multiple images.")
    parser.add_argument("--mask", help="Optional mask image path for direct Images Edit API attempts.")
    parser.add_argument("--out", default="output/imagegen/output.png")
    parser.add_argument("--responses-model", default="gpt-5.5")
    parser.add_argument("--image-model", default="gpt-image-2")
    parser.add_argument("--size", default="1536x1024")
    parser.add_argument("--quality", choices=["low", "medium", "high", "auto"], default="high")
    parser.add_argument("--output-format", choices=["png", "jpeg", "webp"], default="png")
    parser.add_argument("--try-direct-image-api", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    prompt = get_prompt(args)
    api_key = args.api_key or load_codex_auth_key() or os.getenv("NAN_API_KEY") or os.getenv("OPENAI_API_KEY")
    base_url = normalize_base_url(args.base_url)
    if not args.dry_run and not api_key:
        raise SystemExit("Missing API key. Set NAN_API_KEY/OPENAI_API_KEY or sign in through Codex auth.")

    try:
        if args.try_direct_image_api:
            try:
                if try_direct_image_api(args, api_key, base_url, prompt):
                    return 0
            except Exception as exc:
                print(f"DIRECT_FAILED={exc}")
        try_responses_image_tool(args, api_key, base_url, prompt)
        return 0
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        print(f"HTTP_STATUS={exc.code}")
        print(f"ERROR_BODY={body[:1000]}")
        return 1
    except Exception as exc:
        print(f"ERROR={exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())

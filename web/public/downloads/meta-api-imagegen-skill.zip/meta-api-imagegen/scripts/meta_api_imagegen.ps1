[CmdletBinding()]
param(
  [string]$ApiKey,
  [string]$BaseUrl,
  [string]$Prompt,
  [string]$PromptFile,
  [string[]]$Image,
  [string]$Mask,
  [string]$Out = 'output\imagegen\output.png',
  [string]$ResponsesModel = 'gpt-5.5',
  [string]$ImageModel = 'gpt-image-2',
  [string]$Size = '1536x1024',
  [ValidateSet('low','medium','high','auto')]
  [string]$Quality = 'high',
  [ValidateSet('png','jpeg','webp')]
  [string]$OutputFormat = 'png',
  [switch]$TryDirectImageApi,
  [switch]$Force,
  [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Stop-WithMessage([string]$Message) {
  Write-Error $Message
  exit 1
}

function Import-SkillDotEnv {
  $skillEnvPath = Join-Path (Split-Path -Parent $PSScriptRoot) '.env'
  if (-not (Test-Path -LiteralPath $skillEnvPath)) { return }
  foreach ($line in Get-Content -LiteralPath $skillEnvPath -Encoding UTF8) {
    $trimmed = $line.Trim()
    if (-not $trimmed -or $trimmed.StartsWith('#')) { continue }
    $parts = $trimmed -split '=', 2
    if ($parts.Count -ne 2) { continue }
    $name = $parts[0].Trim()
    $value = $parts[1].Trim().Trim('"').Trim("'")
    if ($name) { Set-Item -LiteralPath "Env:$name" -Value $value }
  }
}

function Get-CodexAuthApiKey {
  $authPath = Join-Path $HOME '.codex/auth.json'
  if (-not (Test-Path -LiteralPath $authPath)) { return $null }
  try {
    $auth = Get-Content -LiteralPath $authPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($auth.NAN_API_KEY) { return [string]$auth.NAN_API_KEY }
    if ($auth.OPENAI_API_KEY) { return [string]$auth.OPENAI_API_KEY }
  } catch {
    return $null
  }
  return $null
}

function Get-PromptText {
  if ($Prompt -and $PromptFile) { Stop-WithMessage 'Use -Prompt or -PromptFile, not both.' }
  if ($PromptFile) {
    if (-not (Test-Path -LiteralPath $PromptFile)) { Stop-WithMessage "Prompt file not found: $PromptFile" }
    return (Get-Content -LiteralPath $PromptFile -Raw -Encoding UTF8).Trim()
  }
  if ($Prompt) { return $Prompt.Trim() }
  Stop-WithMessage 'Missing prompt. Use -Prompt or -PromptFile.'
}

function Get-ApiUrl([string]$Path) {
  $base = $BaseUrl.Trim().TrimEnd('/')
  if ($base.EndsWith('/v1')) { $base = $base.Substring(0, $base.Length - 3).TrimEnd('/') }
  return "$base/v1/$($Path.TrimStart('/'))"
}

function ConvertTo-JsonBody($Value) {
  return ($Value | ConvertTo-Json -Depth 40 -Compress)
}

function Convert-ImageToDataUrl([string]$ImagePath) {
  if (-not (Test-Path -LiteralPath $ImagePath)) { Stop-WithMessage "Image not found: $ImagePath" }
  $ext = [IO.Path]::GetExtension($ImagePath).ToLowerInvariant()
  $mime = switch ($ext) {
    '.jpg' { 'image/jpeg' }
    '.jpeg' { 'image/jpeg' }
    '.webp' { 'image/webp' }
    default { 'image/png' }
  }
  $resolved = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ImagePath)
  $b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($resolved))
  return "data:$mime;base64,$b64"
}

function Redact-ImageDataUrls([string]$Json) {
  return [regex]::Replace($Json, 'data:image/[^";,]+;base64,[A-Za-z0-9+/=]+', {
    param($m)
    $prefix = $m.Value.Substring(0, $m.Value.IndexOf(',') + 1)
    return "$prefix<base64:$($m.Value.Length) chars>"
  })
}

function Get-ErrorText($ErrorRecord) {
  if ($ErrorRecord.ErrorDetails -and $ErrorRecord.ErrorDetails.Message) { return $ErrorRecord.ErrorDetails.Message }
  return $ErrorRecord.Exception.Message
}

function Save-Base64Image([string]$ImageBase64, [string]$OutputPath) {
  $dir = Split-Path -Parent $OutputPath
  if ($dir) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  if ((Test-Path -LiteralPath $OutputPath) -and -not $Force) {
    Stop-WithMessage "Output already exists: $OutputPath (use -Force to overwrite)"
  }
  $resolvedOut = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
  [IO.File]::WriteAllBytes($resolvedOut, [Convert]::FromBase64String($ImageBase64))
}

function Find-ImageBase64FromSse([string]$Content) {
  $fallback = $null
  foreach ($line in ($Content -split "`r?`n")) {
    if (-not $line.StartsWith('data: ')) { continue }
    $data = $line.Substring(6).Trim()
    if ($data -eq '[DONE]' -or $data.Length -eq 0) { continue }
    try {
      $obj = $data | ConvertFrom-Json -Depth 100
      $json = $obj | ConvertTo-Json -Depth 100 -Compress
    } catch {
      $json = $data
    }
    foreach ($pattern in @('"result"\s*:\s*"([A-Za-z0-9+/=]{1000,})"','"b64_json"\s*:\s*"([A-Za-z0-9+/=]{1000,})"')) {
      $match = [regex]::Match($json, $pattern)
      if ($match.Success) { return $match.Groups[1].Value }
    }
    $partial = [regex]::Match($json, '"partial_image_b64"\s*:\s*"([A-Za-z0-9+/=]{1000,})"')
    if ($partial.Success) { $fallback = $partial.Groups[1].Value }
  }
  return $fallback
}

function Try-ResponsesImageTool([string]$PromptText) {
  $uri = Get-ApiUrl 'responses'
  $content = @([ordered]@{ type = 'input_text'; text = $PromptText })
  if ($Image) {
    foreach ($imagePath in $Image) {
      $content += [ordered]@{ type = 'input_image'; image_url = (Convert-ImageToDataUrl $imagePath) }
    }
  }
  $payload = [ordered]@{
    model = $ResponsesModel
    input = @(
      [ordered]@{
        role = 'user'
        content = $content
      }
    )
    tools = @(
      [ordered]@{
        type = 'image_generation'
        size = $Size
        quality = $Quality
        output_format = $OutputFormat
      }
    )
    tool_choice = [ordered]@{ type = 'image_generation' }
    stream = $true
  }
  $json = ConvertTo-JsonBody $payload
  $mode = if ($Image) { 'edit' } else { 'generate' }
  Write-Host "TRY_RESPONSES=$uri MODEL=$ResponsesModel MODE=$mode"
  if ($DryRun) {
    Write-Host (Redact-ImageDataUrls $json)
    return @{ ok = $false; skipped = $true; error = 'Dry run.' }
  }
  try {
    $headers = @{ Authorization = "Bearer $ApiKey"; 'Content-Type' = 'application/json'; Accept = 'text/event-stream' }
    $resp = Invoke-WebRequest -Method Post -Uri $uri -Headers $headers -Body $json -TimeoutSec 600
    $b64 = Find-ImageBase64FromSse $resp.Content
    if ($b64) {
      Save-Base64Image $b64 $Out
      return @{ ok = $true; model = $ResponsesModel }
    }
    return @{ ok = $false; error = 'Responses stream completed but no image base64 was found.' }
  } catch {
    return @{ ok = $false; error = (Get-ErrorText $_) }
  }
}

function Try-DirectImageApi([string]$PromptText) {
  if ($Image) {
    return @{ ok = $false; error = 'Direct Images Edit API is only implemented in the Python helper; falling back to Responses image_generation edit mode.' }
  }
  $uri = Get-ApiUrl 'images/generations'
  $payload = [ordered]@{
    model = $ImageModel
    prompt = $PromptText
    size = $Size
    quality = $Quality
    n = 1
    output_format = $OutputFormat
  }
  $json = ConvertTo-JsonBody $payload
  Write-Host "TRY_DIRECT=$uri MODEL=$ImageModel"
  if ($DryRun) {
    Write-Host $json
    return @{ ok = $false; skipped = $true; error = 'Dry run.' }
  }
  try {
    $headers = @{ Authorization = "Bearer $ApiKey"; 'Content-Type' = 'application/json' }
    $resp = Invoke-RestMethod -Method Post -Uri $uri -Headers $headers -Body $json -TimeoutSec 420
    if ($resp.data -and $resp.data.Count -gt 0) {
      $item = $resp.data[0]
      if ($item.b64_json) {
        Save-Base64Image $item.b64_json $Out
        return @{ ok = $true; model = $ImageModel }
      }
      if ($item.url) {
        $dir = Split-Path -Parent $Out
        if ($dir) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Invoke-WebRequest -Uri $item.url -OutFile $Out -TimeoutSec 300 | Out-Null
        return @{ ok = $true; model = $ImageModel }
      }
    }
    return @{ ok = $false; error = 'Direct Image API response had no data[0].b64_json/url.' }
  } catch {
    return @{ ok = $false; error = (Get-ErrorText $_) }
  }
}

Import-SkillDotEnv
if ([string]::IsNullOrWhiteSpace($ApiKey)) { $ApiKey = Get-CodexAuthApiKey }
if ([string]::IsNullOrWhiteSpace($ApiKey)) { $ApiKey = if ($env:NAN_API_KEY) { $env:NAN_API_KEY } else { $env:OPENAI_API_KEY } }
if ([string]::IsNullOrWhiteSpace($BaseUrl)) { $BaseUrl = 'https://cn.meta-api.vip' }
if (-not $DryRun -and [string]::IsNullOrWhiteSpace($ApiKey)) {
  Stop-WithMessage 'Missing API key. Put OPENAI_API_KEY in the skill .env file or pass -ApiKey.'
}

$promptText = Get-PromptText
if ($TryDirectImageApi) {
  $direct = Try-DirectImageApi $promptText
  if ($direct['ok']) {
    Write-Host "WROTE_IMAGE=$Out"
    Write-Host "MODEL=$($direct['model'])"
    exit 0
  }
  Write-Host "DIRECT_FAILED=$($direct['error'])"
}

$responses = Try-ResponsesImageTool $promptText
if ($responses['skipped']) { exit 0 }
if ($responses['ok']) {
  Write-Host "WROTE_IMAGE=$Out"
  Write-Host "MODEL=$($responses['model']) + image_generation tool"
  Write-Host 'NOTE=This is not a direct gpt-image-2 Image API call; the provider may map the image_generation tool internally.'
  exit 0
}

Stop-WithMessage $responses['error']




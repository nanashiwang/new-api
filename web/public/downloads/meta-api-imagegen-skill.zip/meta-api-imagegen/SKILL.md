---
name: meta-api-imagegen
description: Generate or edit raster images through the cn.meta-api.vip third-party OpenAI-compatible base URL using the working /v1/responses image_generation stream flow. Use when the user asks to generate posters, promotional images, hero images, thumbnails, or other bitmap assets, or to edit/transform/retouch an existing image, with this third-party URL/base_url, Meta API, gpt-image-2/Image 2, or when direct /v1/images/generations or /v1/images/edits is unavailable and the provider exposes gpt-5.5 plus image_generation.
---

# Meta API ImageGen

Generate or edit images through `https://cn.meta-api.vip`. For this provider, the observed working path is:

- Endpoint: `POST https://cn.meta-api.vip/v1/responses`
- Outer model: `gpt-5.5`
- Tool: `image_generation`
- Required: `stream: true`
- Input format: list-form `input`, not a plain string. For edits, include local images as `input_image` data URLs after the text instruction.
- API key source: Codex auth/env; no skill-local configuration required

Do not report this as a direct `gpt-image-2` Image API call. In the successful flow, the outer model is `gpt-5.5`; image generation is handled by the Responses `image_generation` tool. The provider's internal image-model mapping is opaque.

## Credentials

Use the bundled Python helper by default. It automatically reads credentials in this order:

1. `-ApiKey` argument, if explicitly supplied.
2. `NAN_API_KEY`, then `OPENAI_API_KEY` from `~/.codex/auth.json`.
3. `NAN_API_KEY`, then `OPENAI_API_KEY` from the process environment.

The default base URL is `https://cn.meta-api.vip`, so normal Codex use does not require a skill-local `.env`.

Do not print the API key in logs, command output, or final responses. If a key was pasted in chat, recommend rotating it later.

## Default Routes

Use Responses generation when there is no source image:

```json
{
  "model": "gpt-5.5",
  "input": [
    {
      "role": "user",
      "content": [
        { "type": "input_text", "text": "<prompt>" }
      ]
    }
  ],
  "tools": [
    {
      "type": "image_generation",
      "size": "1536x1024",
      "quality": "high",
      "output_format": "png"
    }
  ],
  "tool_choice": { "type": "image_generation" },
  "stream": true
}
```

Use Responses edit/reference mode when the user provides an image:

```json
{
  "model": "gpt-5.5",
  "input": [
    {
      "role": "user",
      "content": [
        { "type": "input_text", "text": "<edit instruction>" },
        { "type": "input_image", "image_url": "data:image/png;base64,<source image>" }
      ]
    }
  ],
  "tools": [
    {
      "type": "image_generation",
      "size": "1536x1024",
      "quality": "high",
      "output_format": "png"
    }
  ],
  "tool_choice": { "type": "image_generation" },
  "stream": true
}
```

Parse the full SSE stream and save the final `image_generation_call.result` when present; otherwise save the last `partial_image_b64`. Do not stop at the first partial image.

## Optional Direct Image API Attempt

Only try this if the user specifically wants to test direct Image API support:

- Endpoint: `POST <base>/v1/images/generations`
- Endpoint: `POST <base>/v1/images/edits`
- Model: `gpt-image-2`

For `cn.meta-api.vip`, direct Image API behavior varies, so do not make it the default.

## Script

Use the bundled Python helper:

```bash
python3 "${CODEX_HOME:-$HOME/.codex}/skills/meta-api-imagegen/scripts/meta_api_imagegen.py" \
  --prompt "Generate a polished Chinese promotional poster..." \
  --out "output/imagegen/poster.png"
```

Edit an existing image:

```bash
python3 "${CODEX_HOME:-$HOME/.codex}/skills/meta-api-imagegen/scripts/meta_api_imagegen.py" \
  --image "input/product.png" \
  --prompt "Keep the product shape unchanged, replace the background with a clean white ecommerce studio background, natural soft shadow, no text." \
  --out "output/imagegen/product-edited.png"
```

Useful options:

- `--image input.png` to enter edit/reference mode. Repeat it for multiple reference images.
- `--responses-model gpt-5.5` to set the outer Responses model.
- `--try-direct-image-api --image-model gpt-image-2` to test direct Images generation or edit support.
- `--mask mask.png` to include a mask when using direct Images Edit API attempts.
- `--base-url "https://cn.meta-api.vip"` to override the default base URL.
- `--prompt-file prompt.txt` for long prompts.
- `--size 1536x1024`, `--quality high`, `--output-format png` for common poster output.
- `--dry-run` to print payloads without network calls.

PowerShell helper is also available for Windows-oriented environments:

```powershell
pwsh -ExecutionPolicy Bypass -File "$env:CODEX_HOME\skills\meta-api-imagegen\scripts\meta_api_imagegen.ps1" `
  -Prompt "Generate a polished Chinese promotional poster..." `
  -Out "output\imagegen\poster.png"
```

In restricted network sandboxes, request network escalation before running the real API call.

## Recommended Prompt Shape

For Chinese promotional images, include exact text and layout constraints:

```text
Generate a polished Chinese promotional hero poster for <product>.
The image must contain clear Chinese headline text: <exact title>.
The image must contain clear Chinese subtitle text: <exact subtitle>.
Style: modern commercial ad, warm bright lighting, clean whitespace, clear visual hierarchy.
Constraints: no watermark, no real company logos, no garbled text, no large unrelated English text.
```

After generation, inspect the saved image before reporting success. Check that the file opens, the subject matches, and text is not obviously corrupted.
